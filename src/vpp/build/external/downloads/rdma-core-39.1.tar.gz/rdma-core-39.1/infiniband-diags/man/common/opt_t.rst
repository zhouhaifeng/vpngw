.. Define the common option -t

**-t, --timeout <timeout_ms>** override the default timeout for the solicited mads.

